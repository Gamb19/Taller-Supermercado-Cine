/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package co.edu.udes.cine;

import java.util.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.*;
import java.time.format.DateTimeParseException;

/**
 *
 * @author molin
 */
public class Cine {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<movie> movie = new ArrayList<>();
        ArrayList<Customer> client = new ArrayList<>();
        ArrayList<employer> empleado = new ArrayList<>();
        ArrayList<Salas> sala = new ArrayList<>();
        ArrayList<ticket> tickets = new ArrayList<>();
        ArrayList<confectionery> product = new ArrayList<>();
        System.out.println("--Menu--");

        int option = 0;

        do {
            System.out.println("1.Salas \n2.Personas(Empleado o cliente) \n3.Peliculas \n4.Ticket \n5.Confiteria (Producto) \n6.Mostrar \n7.Salir");
            option = sc.nextInt();

            switch (option) {
                case 1:
                    if (movie.isEmpty() == true) {
                        System.out.println("No puedes agregar una sala, sin antes haber agregado una pelicula");
                        break;
                    } else {
                        AddSala(sc, sala, movie);
                        break;
                    }

                case 2:
                    if (sala.isEmpty() == true) {
                        System.out.println("No puedes agregar una persona, sin antes haber agregado una sala");
                        break;
                    } else {
                        AddPerson(sc, client, empleado);
                        break;
                    }
                case 3:
                    Addmovie(sc, movie);
                    break;
                case 4:
                    if (empleado.isEmpty() == true) {
                        System.out.println("No puedes agregar tickets porque no hay empleados que hagan esta labor");
                        break;
                    } else {
                        AddTicket(sc, tickets, sala);
                        break;
                    }
                case 5:
                    if (empleado.isEmpty() == true) {
                        System.out.println("No puedes agregar productos a la confiteria, sin que hayan empleados que hagan esta labor");
                        break;
                    } else {
                        AddConfectionary(sc, product);
                        break;
                    }
                case 6:
                    Listar(sc, movie, sala, client, empleado, tickets, product);
            }
        } while (option <= 6);
    }
    public static void AddSala(Scanner sc, ArrayList<Salas> sala, ArrayList<movie> movie) {

        int number_hallUser, capacityUser;
        String movieUser;

        System.out.println("Películas disponibles:");
        for (int i = 0; i < movie.size(); i++) {
            System.out.println((i + 1) + ". " + movie.get(i).getName());
        }

        System.out.println("Ingrese el número de la película que desea asignar a la sala: ");
        int selectedMovie = sc.nextInt();
        sc.nextLine();

        boolean validNumber = false;
        while (!validNumber) {
            System.out.println("Ingrese el número de la sala: ");
            number_hallUser = sc.nextInt();
            sc.nextLine();

            boolean exists = false;
            for (Salas s : sala) {
                if (s.getNumber_hall() == number_hallUser) {
                    exists = true;
                    break;
                }
            }

            if (!exists) {
                validNumber = true;
                System.out.println("Capacidad de la sala: ");
                capacityUser = sc.nextInt();
                sc.nextLine();

                movieUser = movie.get(selectedMovie - 1).getName();
                sala.add(new Salas(capacityUser, number_hallUser, movieUser));
                System.out.println("Sala agregada exitosamente.");
            } else {
                System.out.println("Ya existe una sala con ese número. Por favor, ingrese otro número o seleccione otra opción del menú.");
                System.out.println("Presione 1 para intentar nuevamente, o cualquier otro número para regresar al menú.");
                int retry = sc.nextInt();
                sc.nextLine();
                if (retry != 1) {
                    break;
                }
            }
        }
    }
    public static void Addmovie(Scanner sc, ArrayList<movie> movie) {
        String nombre, duracion, fecha_salida;
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");

        System.out.println("Nombre de la pelicula: \n");
        sc.nextLine(); // Limpiar el búfer de entrada
        nombre = sc.nextLine();

        System.out.println("Duracion de la pelicula (HH:mm) (En caso de ser menor a 10 horas agregar un 0 antes del numero ejm: 01:30): \n");
        duracion = sc.next();
        sc.nextLine();
        LocalTime hora = LocalTime.parse(duracion, formatter);

        // Validación de la fecha
        boolean fechaValida = false;
        LocalDate fecha = null;
        while (!fechaValida) {
            try {
                System.out.println("Fecha de salida (dd/MM/yyyy): \n");
                fecha_salida = sc.next();
                fecha = LocalDate.parse(fecha_salida, formato);
                fechaValida = true;
            } catch (DateTimeParseException e) {
                System.out.println("Fecha inválida. Intente de nuevo.");
            }
        }

        movie.add(new movie(nombre, hora.format(formatter), fecha.format(formato)));

    }
    public static void AddPerson(Scanner sc, ArrayList<Customer> client, ArrayList<employer> empleado) {
        System.out.println("--Sub menu personas--- \n");
        int option = 0;
        do {
            System.out.println("1.Empleado \n2.Cliente \n3.salir");
            option = sc.nextInt();
            try {

            } catch (NumberFormatException e) {
                System.out.println("Ingrese una opción válida");
                continue;
            }

            switch (option) {
                case 1 -> {
                    System.out.println("Nombre del empleado: ");
                    String nombreEmpleado = sc.next();

                    System.out.println("Tipo del empleado (Taquilla, Limpieza. Etc): ");
                    String tipoEmpleado = sc.next();

                    System.out.println("Salario del empleado");
                    double SalarioEmpleado = sc.nextDouble();

                    System.out.println("Id del empleado");
                    int idEmpleado = sc.nextInt();

                    empleado.add(new employer(tipoEmpleado, SalarioEmpleado, nombreEmpleado, idEmpleado));
                }
                case 2 -> {
                    System.out.println("Nombre del cliente");
                    String nombreCliente = sc.next();

                    System.out.println("Telefono del cliente");
                    String telefonoCliente = sc.next();

                    System.out.println("Correo cliente");
                    String correoCliente = sc.next();

                    System.out.println("Id del cliente");
                    int IdCliente = sc.nextInt();

                    client.add(new Customer(telefonoCliente, correoCliente, nombreCliente, IdCliente));

                }
            }
        } while (option <= 2);

    }
    public static void AddTicket(Scanner sc, ArrayList<ticket> tickets, ArrayList<Salas> sala) {
        System.out.println("Seleccione la sala: ");
        for (int i = 0; i < sala.size(); i++) {
            System.out.println((i + 1) + ". Sala " + sala.get(i).getNumber_hall() + ": " + sala.get(i).getMovie());
        }

        int selectedHall = sc.nextInt();
        sc.nextLine();

        Salas selectedSala = sala.get(selectedHall - 1);
        String selectedMovie = selectedSala.getMovie();

        System.out.println("Seleccione el asiento (letra y número): ");
        String seat = sc.nextLine();

        double ticketPrice = 0.0;
        boolean validPrice = false;
        while (!validPrice) {
            System.out.println("Ingrese el precio del boleto: ");
            try {
                ticketPrice = Double.parseDouble(sc.nextLine());
                validPrice = true;
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
            }
        }

        if (selectedSala.getTickets().size() >= selectedSala.getCapacity()) {
            System.out.println("Lo siento, la sala está llena. No se puede agregar más tickets.");
            return;
        }

        ticket newTicket = new ticket(selectedMovie, ticketPrice, seat, selectedHall);
        selectedSala.getTickets().add(newTicket);
        tickets.add(newTicket);

    }
    public static void AddConfectionary(Scanner sc, ArrayList<confectionery> product) {
       
        System.out.println("Nombre del producto: ");
         sc.nextLine();
        String name = sc.nextLine();

        System.out.println("Precio del producto: ");
        double price = sc.nextDouble();

        System.out.println("Cantidad de ese producto: ");
        int amount = sc.nextInt();

        product.add(new confectionery(price, name, amount));
    }
    public static void Listar(Scanner sc, ArrayList<movie> movie, ArrayList<Salas> sala, ArrayList<Customer> client, ArrayList<employer> empleado, ArrayList<ticket> tickets, ArrayList<confectionery> products) {

        int option = 0;

        do {
            System.out.println("Que quieres Listar");
            System.out.println("1.Salas \n2.Peliculas \n3.Personas(Empleados o Clientes) \n4.Tickets \n5.Productos \n6.Todo \n 7.Salir");
            option = sc.nextInt();

            switch (option) {
                case 1:
                    System.out.println("Salas: ");
                    for (Salas objeto : sala) {
                        String movieSala = objeto.getMovie();
                        int capacity = objeto.getCapacity();
                        int numeber_hall = objeto.getNumber_hall();

                        System.out.println("Pelicula asignada: " + movieSala + "\nCapacidad de la sala: " + capacity + "\nNumero de la sala: " + numeber_hall);
                        System.out.println();

                    }
                    break;
                case 2:
                    System.out.println();
                    System.out.println("Peliculas: ");
                    for (movie objeto : movie) {
                        String nombre = objeto.getName();
                        String duration = objeto.getDuration();
                        String release = objeto.getRelease_Date();

                        System.out.println("Nombre de la pelicula: " + nombre + "\nDuracion de la pelicula: " + duration + "\nFecha de lanzamiento: " + release);
                        System.out.println();
                    }
                    break;
                case 3:
                    System.out.println("Desea ver clientes o empleados (1 Clientes 2 Empleados)");
                    int election = sc.nextInt();
                    switch (election) {
                        case 1 -> {
                            System.out.println();
                            System.out.println("Clientes");
                            for (Customer objeto : client) {
                                String name = objeto.getName();
                                int id = objeto.getId();
                                String cellphone = objeto.getTelephone();
                                String correo = objeto.getCorreo();

                                System.out.println("Nombre Cliente: " + name + "\nTelefono: " + cellphone + "\nCorreo: " + correo + "\nId: " + id);
                            }
                            break;
                        }
                        case 2 -> {
                            System.out.println("Empleados");
                            for (employer objeto : empleado) {
                                String name = objeto.getName();
                                String tipo_empleado = objeto.getTipe_employee();
                                int id = objeto.getId();
                                double salary = objeto.getSalary();
                                System.out.println("Nombre empleado: " + name + "\nTipo de empleado: " + tipo_empleado + "\nSalario: " + salary + "\nId: " + id);
                                System.out.println();
                            }
                            break;
                        }
                        default ->
                            System.out.println("Opcion incorrecta");
                    }
                    break;
                case 4:
                    System.out.println();
                    System.out.println("Tickets: ");
                    for (ticket objeto : tickets) {
                        String pelicula = objeto.getMovie();
                        double precio = objeto.getPrice();
                        String Asiento = objeto.getSeat();
                        int Sala = objeto.getHall();

                        System.out.println("Pelicula del ticket: " + pelicula + "\nPrecio del ticket: " + precio + "\n Asiento: " + Asiento + "\nSala del ticket: " + Sala);
                    }
                    break;
                case 5:
                    System.out.println();
                    System.out.println("Productos:");
                    Collections.sort(products, (confectionery c1, confectionery c2) -> {
                        return c1.getProduct().compareTo(c2.getProduct());
                    });

// Recorrer la lista de productos e imprimir la información de cada uno
                    System.out.println("Productos:");
                    for (confectionery c : products) {
                        if (c.getProduct() == null || c.getProduct().isEmpty()) {
                            System.out.println("Error: producto sin nombre.");
                            continue;
                        }
                        System.out.println("- " + c.getProduct() + " | Precio: $" + c.getPrice() + " | Cantidad: " + c.getAmount_product());
                    }
                    break;
                case 6:
                    System.out.println("Salas: ");
                    for (Salas objeto : sala) {
                        String movieSala = objeto.getMovie();
                        int capacity = objeto.getCapacity();
                        int numeber_hall = objeto.getNumber_hall();

                        System.out.println("Pelicula asignada: " + movieSala + "\nCapacidad de la sala: " + capacity + "\nNumero de la sala: " + numeber_hall);
                        System.out.println();
                    }
                    System.out.println();
                    System.out.println("Peliculas: ");
                    for (movie objeto : movie) {
                        String nombre = objeto.getName();
                        String duration = objeto.getDuration();
                        String release = objeto.getRelease_Date();

                        System.out.println("Nombre de la pelicula \n" + nombre + "\nDuracion de la pelicula: " + duration + "\nFecha de lanzamiento: " + release);
                        System.out.println();
                    }
                    System.out.println();
                    System.out.println("Clientes");
                    for (Customer objeto : client) {
                        String name = objeto.getName();
                        int id = objeto.getId();
                        String cellphone = objeto.getTelephone();
                        String correo = objeto.getCorreo();

                        System.out.println("Nombre Cliente: " + name + "\nTelefono: " + cellphone + "\nCorreo: " + correo + "\nId: " + id);
                    }
                    System.out.println("Empleados");
                    for (employer objeto : empleado) {
                        String name = objeto.getName();
                        String tipo_empleado = objeto.getTipe_employee();
                        int id = objeto.getId();
                        double salary = objeto.getSalary();
                        System.out.println("Nombre empleado: " + name + "\nTipo de empleado: " + tipo_empleado + "\nSalario: " + salary + "\nId: " + id);
                        System.out.println();
                    }
                    System.out.println();
                    System.out.println("Tickets: ");
                    for (ticket objeto : tickets) {
                        String pelicula = objeto.getMovie();
                        double precio = objeto.getPrice();
                        String Asiento = objeto.getSeat();
                        int Sala = objeto.getHall();

                        System.out.println("Pelicula del ticket: " + pelicula + "\nPrecio del ticket: " + precio + "\n Asiento: " + Asiento + "\nSala del ticket: " + Sala);
                    }
                    System.out.println();
                    System.out.println("Productos:");
                    Collections.sort(products, (confectionery c1, confectionery c2) -> {
                        return c1.getProduct().compareTo(c2.getProduct());
                    });

                    // Recorrer la lista de productos e imprimir la información de cada uno
                    for (confectionery c : products) {
                        System.out.println("- " + c.getProduct() + " | Precio: $" + c.getPrice() + " | Cantidad: " + c.getAmount_product());
                    }
                    break;
            }

        } while (option <= 6);
    }
}
