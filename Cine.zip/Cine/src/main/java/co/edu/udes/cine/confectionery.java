/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;

/**
 *
 * @author molin
 */
public class confectionery {
    private double price;
    private String product;
    private int amount_product;

    public confectionery() {
    }

    public confectionery(double price, String product, int amount_product) {
        this.price = price;
        this.product = product;
        this.amount_product = amount_product;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public int getAmount_product() {
        return amount_product;
    }

    public void setAmount_product(int amount_product) {
        this.amount_product = amount_product;
    }
    
    
    
}
