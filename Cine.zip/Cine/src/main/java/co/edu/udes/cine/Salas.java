/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;
import java.util.*;
/**
 *
 * @author molin
 */
public class Salas {
   private int capacity;
    private int number_hall;
    private String movie;
    private ArrayList<ticket> tickets;

    public Salas() {
        tickets = new ArrayList<>();
    }

    public Salas(int capacity, int number_hall, String movie) {
        this.capacity = capacity;
        this.number_hall = number_hall;
        this.movie = movie;
        tickets = new ArrayList<>();
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getNumber_hall() {
        return number_hall;
    }

    public void setNumber_hall(int number_hall) {
        this.number_hall = number_hall;
    }

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public ArrayList<ticket> getTickets() {
        return tickets;
    }

    public void setTickets(ArrayList<ticket> tickets) {
        this.tickets = tickets;
    }

    
    
}
