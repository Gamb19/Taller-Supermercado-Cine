/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;

/**
 *
 * @author molin
 */
public class Customer extends person {
    String telephone;
    String correo;

    public Customer(String telephone, String correo) {
        this.telephone = telephone;
        this.correo = correo;
    }

    public Customer(String telephone, String correo, String name, int id) {
        super(name, id);
        this.telephone = telephone;
        this.correo = correo;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    
}
