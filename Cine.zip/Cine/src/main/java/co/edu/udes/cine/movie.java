/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;
import java.time.*;
/**
 *
 * @author molin
 */
public class movie {
    private String name;
    private String duration;
    private String release_Date;
    

    public movie() {
    }

    public movie(String name, String duration, String release_Date) {
        this.name = name;
        this.duration = duration;
        this.release_Date = release_Date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getRelease_Date() {
        return release_Date;
    }

    public void setRelease_Date(String release_Date) {
        this.release_Date = release_Date;
    }
  
}
