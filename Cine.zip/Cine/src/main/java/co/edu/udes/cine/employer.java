/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;

/**
 *
 * @author molin
 */
public class employer extends person {
   String tipe_employee;
   double Salary;
    public employer(String tipe_employee, double Salary, String name, int id) {
        super(name, id);
        this.tipe_employee = tipe_employee;
        this.Salary = Salary;
    }

    public String getTipe_employee() {
        return tipe_employee;
    }

    public void setTipe_employee(String tipe_employee) {
        this.tipe_employee = tipe_employee;
    }

    public double getSalary() {
        return Salary;
    }

    public void setSalary(double Salary) {
        this.Salary = Salary;
    }

    public employer() {
    }
   
}
