/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;

/**
 *
 * @author molin
 */
public class ticket {
    private String movie;
    private double price;
    private String seat;
    private int hall;

    public ticket(String movie, double price, String seat, int hall) {
        this.movie = movie;
        this.price = price;
        this.seat = seat;
        this.hall = hall;
    }

    
    
    public int getHall() {
        return hall;
    }

    public void setHall(int hall) {
        this.hall = hall;
    }
   
    public ticket() {
    }
    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    
    
}
